const CACHE='linhthu-v2';
const CORE=["./", "index.html", "manifest.json", "icon-192.png", "icon-512.png", "pets/stage1.jpg", "pets/stage2.jpg", "pets/stage3.jpg", "pets/stage4.jpg", "pets/stage5.jpg", "pets/stage6.jpg", "pets/stage7.jpg", "pets/stage8.jpg", "pets/stage9.jpg", "pets/stage10.jpg", "pets/stage11.jpg", "pets/stage12.jpg", "pets/stage13.jpg", "pets/stage14.jpg"];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE)).then(()=>self.skipWaiting()));});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));});
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET'||r.headers.has('range'))return; // video dùng range request -> để trình duyệt tự xử lý
  const u=new URL(r.url);
  if(u.origin!==location.origin)return;
  // HTML: ưu tiên mạng để luôn có bản mới, mất mạng thì dùng cache
  if(r.mode==='navigate'){e.respondWith(fetch(r).then(res=>{const c=res.clone();caches.open(CACHE).then(x=>x.put('index.html',c));return res;}).catch(()=>caches.match('index.html')));return;}
  e.respondWith(caches.match(r).then(m=>m||fetch(r).then(res=>{if(res.ok&&res.status===200&&!u.pathname.endsWith('.mp4')){const c=res.clone();caches.open(CACHE).then(x=>x.put(r,c));}return res;})));
});
